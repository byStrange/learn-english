// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file Blockquote.tsx
 * @input Uses React, stylex, spacing and color tokens
 * @output Exports Blockquote component and BlockquoteProps
 * @position Blockquote component; renders styled quotations with optional attribution
 *
 * SYNC: When modified, update these files to stay in sync:
 * - /packages/core/src/Blockquote/Blockquote.doc.mjs
 * - /packages/core/src/Blockquote/Blockquote.test.tsx
 * - /apps/storybook/stories/Blockquote.stories.tsx
 * - /packages/cli/assets/templates/blocks/components/Blockquote/ (showcase blocks)
 */

import type {ReactNode} from 'react';
import type {BaseProps} from '../BaseProps';
import * as stylex from '@stylexjs/stylex';
import {colorVars, spacingVars, typeScaleVars} from '../theme/tokens.stylex';
import {isRenderable, mergeProps} from '../utils';
import {themeProps} from '../utils/themeProps';

export interface BlockquoteProps extends BaseProps<HTMLQuoteElement> {
  /** Ref forwarded to the root <blockquote> element */
  ref?: React.Ref<HTMLQuoteElement>;
  /** Content of the blockquote */
  children: ReactNode;
  /**
   * Optional attribution for the quote. Rendered in a `<cite>` element after
   * the quoted content.
   */
  cite?: ReactNode;
}

const styles = stylex.create({
  root: {
    borderInlineStartWidth: spacingVars['--spacing-0-5'],
    borderInlineStartStyle: 'solid',
    borderInlineStartColor: colorVars['--color-border-emphasized'],
    paddingInlineStart: spacingVars['--spacing-4'],
    color: colorVars['--color-text-secondary'],
    overflowWrap: 'break-word',
    marginInlineStart: 0,
    marginInlineEnd: 0,
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  cite: {
    display: 'block',
    marginBlockStart: spacingVars['--spacing-2'],
    fontSize: typeScaleVars['--text-supporting-size'],
    lineHeight: typeScaleVars['--text-supporting-leading'],
    fontStyle: 'normal',
  },
});

/**
 * Blockquote component for displaying quoted content.
 *
 * Renders a semantic `<blockquote>` with an inline-start rule and secondary
 * text color, matching the Curialy UI visual language.
 *
 * @example
 * ```
 * <Blockquote>Design is not just what it looks like.</Blockquote>
 * ```
 */
export function Blockquote({
  children,
  cite,
  xstyle,
  className,
  style,
  ref,
  ...props
}: BlockquoteProps) {
  return (
    <blockquote
      ref={ref}
      {...mergeProps(
        themeProps('blockquote'),
        stylex.props(styles.root, xstyle),
        className,
        style,
      )}
      {...props}>
      {children}
      {/*
        A bare <cite>, never wrapped in <footer>: <blockquote> is a sectioning
        root, so a <footer> inside it maps to a contentinfo document landmark.
      */}
      {isRenderable(cite) && <cite {...stylex.props(styles.cite)}>{cite}</cite>}
    </blockquote>
  );
}

Blockquote.displayName = 'Blockquote';
