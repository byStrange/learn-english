// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file highlightStyles.ts
 * @input Syntax token defaults from domainTokens
 * @output Injects ::highlight() CSS rules + fallback token values into the document head
 * @position Shared utility; consumed by CodeBlock and CodeEditor
 *
 * SYNC: When modified, update:
 * - /packages/core/src/theme/domainTokens/syntaxTokens.ts (syntax color token names/defaults)
 */

import {syntaxTokenDefaults} from '../theme';

/**
 * Build the fallback CSS custom properties from the syntax token defaults.
 * These provide colors when no theme explicitly sets --color-syntax-* tokens.
 * Themes override these via higher-specificity [data-cui-theme] selectors.
 */
const FALLBACK_TOKENS = `:root {\n${Object.entries(syntaxTokenDefaults)
  .map(([name, value]) => `  ${name}: ${value};`)
  .join('\n')}\n}`;

/**
 * Scoped ::highlight() rules — attached to the `code` element so the
 * browser only checks highlight ranges within code content, not the
 * entire document tree. Using `code::highlight()` instead of bare
 * `::highlight()` avoids expensive style recalc on every element.
 */
const HIGHLIGHT_STYLES = `
${FALLBACK_TOKENS}

.cui-code-block code::highlight(cui-keyword),
.cui-codeeditor code::highlight(cui-keyword) { color: var(--color-syntax-keyword); }
.cui-code-block code::highlight(cui-string),
.cui-codeeditor code::highlight(cui-string) { color: var(--color-syntax-string); }
.cui-code-block code::highlight(cui-comment),
.cui-codeeditor code::highlight(cui-comment) { color: var(--color-syntax-comment); }
.cui-code-block code::highlight(cui-number),
.cui-codeeditor code::highlight(cui-number) { color: var(--color-syntax-number); }
.cui-code-block code::highlight(cui-function),
.cui-codeeditor code::highlight(cui-function) { color: var(--color-syntax-function); }
.cui-code-block code::highlight(cui-type),
.cui-codeeditor code::highlight(cui-type) { color: var(--color-syntax-type); }
.cui-code-block code::highlight(cui-tag),
.cui-codeeditor code::highlight(cui-tag) { color: var(--color-syntax-tag); }
.cui-code-block code::highlight(cui-attribute),
.cui-codeeditor code::highlight(cui-attribute) { color: var(--color-syntax-attribute); }
.cui-code-block code::highlight(cui-property),
.cui-codeeditor code::highlight(cui-property) { color: var(--color-syntax-property); }
.cui-code-block code::highlight(cui-operator),
.cui-codeeditor code::highlight(cui-operator) { color: var(--color-syntax-operator); }
.cui-code-block code::highlight(cui-constant),
.cui-codeeditor code::highlight(cui-constant) { color: var(--color-syntax-constant); }
.cui-code-block code::highlight(cui-punctuation),
.cui-codeeditor code::highlight(cui-punctuation) { color: var(--color-syntax-punctuation); }
.cui-code-block code::highlight(cui-variable),
.cui-codeeditor code::highlight(cui-variable) { color: var(--color-syntax-variable); }

/* Span-based fallback classes — used when highlightMode='spans' or
   when the CSS Custom Highlight API is not available. */
.cui-token-keyword         { color: var(--color-syntax-keyword); }
.cui-token-string           { color: var(--color-syntax-string); }
.cui-token-comment         { color: var(--color-syntax-comment); }
.cui-token-number           { color: var(--color-syntax-number); }
.cui-token-function       { color: var(--color-syntax-function); }
.cui-token-type               { color: var(--color-syntax-type); }
.cui-token-tag                 { color: var(--color-syntax-tag); }
.cui-token-attribute     { color: var(--color-syntax-attribute); }
.cui-token-property       { color: var(--color-syntax-property); }
.cui-token-operator       { color: var(--color-syntax-operator); }
.cui-token-constant       { color: var(--color-syntax-constant); }
.cui-token-punctuation { color: var(--color-syntax-punctuation); }
.cui-token-variable       { color: var(--color-syntax-variable); }
`;

let inserted = false;

/**
 * Injects the ::highlight() CSS rules into the document <head>.
 * Safe to call multiple times — only injects once.
 */
export function ensureHighlightStyles(): void {
  if (inserted) {
    return;
  }
  if (typeof document === 'undefined') {
    return;
  }

  const style = document.createElement('style');
  style.setAttribute('data-cui-highlight-styles', '');
  style.textContent = HIGHLIGHT_STYLES;
  document.head.appendChild(style);
  inserted = true;
}

/**
 * Token types that map to highlight names.
 * Used to create CSS.highlights entries with the `cui-` prefix.
 */
export const TOKEN_TYPES = [
  'keyword',
  'string',
  'comment',
  'number',
  'function',
  'type',
  'tag',
  'attribute',
  'property',
  'operator',
  'constant',
  'punctuation',
  'variable',
] as const;
