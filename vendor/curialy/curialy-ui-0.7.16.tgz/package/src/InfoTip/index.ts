// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file InfoTip component barrel export
 * @input InfoTip.tsx
 * @output Exports InfoTip, InfoTipProps, InfoTipSize
 * @position Barrel; consumed by packages/core/src/index.ts and the
 *   `@curialy/ui/InfoTip` entry
 */

export {InfoTip} from './InfoTip';
export type {InfoTipProps, InfoTipSize} from './InfoTip';
