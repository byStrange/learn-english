// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file ChatPastedTextToken.tsx
 * @input Uses React, StyleX, Badge, HoverCard, Button, provider-bound translator,
 *   the shared tap stop (`useTapStop`)
 * @output Exports ChatPastedTextToken component
 * @position Inline token for pasted text with hover card preview + expand
 *
 * Hover, or a tap by finger or pen: card with truncated text preview and
 * "Expand" button. Expand replaces the token with the full text in the
 * contentEditable.
 *
 * SYNC: When modified, update:
 * - /packages/core/src/Chat/index.ts (exports)
 */

import * as stylex from '@stylexjs/stylex';
import {
  colorVars,
  spacingVars,
  typeScaleVars,
  typographyVars,
} from '../theme/tokens.stylex';
import {Badge} from '../Badge';
import {Button} from '../Button';
import {HoverCard} from '../HoverCard';
import type {TranslatorFn} from '../i18n';
import {useTapStop} from '../Layer/useTouchTrigger';
import {
  registerEnglishFallback,
  useComponentTranslator,
} from '../i18n/useComponentTranslator';
import english from '../i18n/generated-english/Chat/ChatPastedTextToken.generated';

registerEnglishFallback(english);

// =============================================================================
// Types
// =============================================================================

export interface ChatPastedTextTokenProps {
  /** The full pasted text. */
  text: string;
  /** Called when the user clicks Expand — dissolves the token into editable text. */
  onExpand?: () => void;
}

// =============================================================================
// Styles
// =============================================================================

const styles = stylex.create({
  preview: {
    display: 'flex',
    flexDirection: 'column',
    gap: spacingVars['--spacing-2'],
    maxWidth: '480px',
  },
  previewText: {
    fontFamily: typographyVars['--font-family-code'],
    fontSize: typeScaleVars['--text-supporting-size'],
    lineHeight: typeScaleVars['--text-supporting-leading'],
    color: colorVars['--color-text-primary'],
    whiteSpace: 'pre-wrap',
    wordBreak: 'break-word',
    maxHeight: '240px',
    overflowY: 'auto',
  },
  footer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacingVars['--spacing-2'],
  },
  meta: {
    fontSize: typeScaleVars['--text-supporting-size'],
    color: colorVars['--color-text-secondary'],
  },
});

// =============================================================================
// Helpers
// =============================================================================

function formatLabel(text: string, t: TranslatorFn): string {
  return t('@cui.chat.pastedText.label', {
    lines: text.split('\n').length,
    chars: text.length,
  });
}

// =============================================================================
// Component
// =============================================================================

export function ChatPastedTextToken({
  text,
  onExpand,
}: ChatPastedTextTokenProps) {
  const t = useComponentTranslator();
  const label = formatLabel(text, t);
  // A tap on the token, by finger or pen, asks for its preview, so it stops
  // there: cancelling the mouse press the browser makes of it keeps the
  // composer around the token from taking focus and the caret, which on a
  // touch device raises the keyboard over the preview. The tap's click still
  // reaches the card's trigger. A mouse press still places the caret, and
  // hover opens the preview.
  const tapStop = useTapStop('mousedown');

  const cardContent = (
    <div {...stylex.props(styles.preview)}>
      <div {...stylex.props(styles.previewText)}>{text}</div>
      <div {...stylex.props(styles.footer)}>
        <span {...stylex.props(styles.meta)}>{label}</span>
        {onExpand && (
          <Button
            label={t('@cui.chat.pastedText.expand')}
            variant="ghost"
            size="sm"
            onClick={onExpand}
          />
        )}
      </div>
    </div>
  );

  return (
    <HoverCard
      content={cardContent}
      placement="above"
      alignment="start"
      hasHoverIndication={false}>
      <Badge label={label} variant="neutral" {...tapStop} />
    </HoverCard>
  );
}

ChatPastedTextToken.displayName = 'ChatPastedTextToken';
