// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @output Public single-node renderer for Markdown plugin extension nodes
 * @position Client-only subpath entry point:
 *   `@curialy/ui/Markdown/plugin-renderer`
 */

export {MarkdownPluginNodeRenderer} from './MarkdownPluginNodeRenderer';
export type {MarkdownPluginNodeRendererProps} from './MarkdownPluginNodeRenderer';
