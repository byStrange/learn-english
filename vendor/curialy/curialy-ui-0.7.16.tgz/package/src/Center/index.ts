// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file index.ts
 * @input Imports Center component
 * @output Exports Center and types for @curialy/ui/Center
 * @position Entry point for Center component
 *
 * SYNC: When modified, update /packages/core/src/Center/Center.doc.mjs
 */

export {Center} from './Center';
export type {CenterProps, CenterAxis} from './Center';
